/*author: Gabriel Sawka and Wiliam Martin
* date: 25 april
* description: constant to modify to change the scale of the visuals
*/
const int HORIZONTAL_MARGIN = 200;
const int VERTICAL_MARGIN = 100;
const int SQUARE_SIZE = 100;
const int NB_BOX = 8;