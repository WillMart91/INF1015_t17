/*author: Gabriel Sawka and Wiliam Martin
* date: 25 april
* description: class declaring a king piece
*/


#pragma once

#include "AbsPiece.h"
class King :public AbsPiece
{
public:
	King(bool blackTeam, Square beginPos);
	virtual std::vector<Square> getValidPositions(const std::vector<std::vector<AbsPiece*>> chessBoard);
	bool isChecked(const std::vector<std::vector<AbsPiece*>> chessBoard);
	~King();
	//AbsPiece* castle();
private:
	static int nbOfKings;

	const int range = 1;
	const std::vector<std::pair<int, int>> direction = { {1, 0}, {1,1}, {0,1}, {-1,1}, {-1,0}, {-1,-1}, {0,-1}, {1,-1} };
	const std::vector<std::pair<int, int>> rookDir = { {1, 0}, {0,1}, {-1,0}, {0,-1}};
	const std::vector<std::pair<int, int>> bishopDir = { {1,1}, {-1,1},{-1,-1}, {1,-1} };
	const std::vector<std::pair<int, int>> knightDir = { {2, 1}, {2,-1}, {-2,1}, {-2,-1}, {1,2}, {1,-2}, {-1,2}, {-1,-2} };
};

